import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Person {
    private String name;
    private LocalDate dateOfBirth;
    private LocalDate dateOfDeath;
    private Person mother;
    private Person father;
    private List<Person> parents=new ArrayList<>();
    public Person(String name, LocalDate dateOfBirth, LocalDate dateOfDeath, Person mother, Person father) {
        this.name = name;
        this.dateOfBirth = dateOfBirth;
        this.dateOfDeath = dateOfDeath;
        this.mother = mother;
        this.father = father;
        parents.add(mother);
        parents.add(father);
    }

    public static List<Person> fromCsv(String path) {
        List<Person> people = new ArrayList<>();

        try {
            BufferedReader br = new BufferedReader(new FileReader(path));
            br.readLine();

            String line;
            while ((line = br.readLine())  != null){
                fromCsvLine(line, people);
            }
            return people;

        } catch (Exception e) {
            System.err.println("Nie mogę odczytać pliku");
            return null;
        }
    }


    public static void fromCsvLine(String line, List<Person> people) {
        String name = null;
        LocalDate dateOfBirth = null;
        LocalDate dateOfDeath = null;

        Person mother = null;
        Person father = null;

        try {
            String[] parts = line.split(",");


            int numOfCols = parts.length;

            if (numOfCols > 0) {
                name = parts[0].trim();
            }

            if (numOfCols > 1) {
                String dob = parts[1].trim();
                if (!dob.isEmpty()) {
                    dateOfBirth = LocalDate.parse(dob, DateTimeFormatter.ofPattern("dd.MM.yyyy"));
                }
            }

            if (numOfCols > 2) {
                String dod = parts[2].trim();
                if (!dod.isEmpty()) {
                    dateOfDeath = LocalDate.parse(dod, DateTimeFormatter.ofPattern("dd.MM.yyyy"));
                }
            }

            if (numOfCols >3){
                String motherName=parts[3].trim();
                for (Person potentialMother : people){
                    if (motherName.equals(potentialMother.name)){
                        mother=potentialMother;
                        LocalDate dateMinus15=dateOfBirth.minusYears(15);
                        if (dateMinus15.isBefore(mother.dateOfBirth) || (mother.dateOfDeath!=null && dateOfBirth.isAfter(mother.dateOfDeath))) {
                            throw new ParentingAgeException(mother.name);
                        }
                        break;

                    }
                }
            }

            if (numOfCols>4){
                String fatherName=parts[4].trim();
                for (Person potentialFather : people){
                    if (fatherName.equals(potentialFather.name)){
                        father=potentialFather;
                        LocalDate dateMinus15=dateOfBirth.minusYears(15);
                        if (dateMinus15.isBefore(father.dateOfBirth) || (father.dateOfDeath!=null && dateOfBirth.isAfter(father.dateOfDeath))) {
                            throw new ParentingAgeException(father.name);
                        }
                        break;
                    }
                }
            }


            if (dateOfBirth != null && dateOfDeath != null && dateOfDeath.isBefore(dateOfBirth)) {
                throw new NegativeLifespanException(name);
            }

            for (Person person : people){
                if (person.name.equals(parts[0])){
                    throw new AmbiguousPersonException(person.name);
                }
            }

            people.add(new Person(name, dateOfBirth, dateOfDeath, mother, father));
        }

        catch (ParentingAgeException e){
            System.err.println(e.getMessage());
            Scanner scan = new Scanner(System.in);
            System.out.println("Enter Y to save");

            String answer = scan.nextLine();

            if (answer.equals("Y")){
                people.add(new Person(name, dateOfBirth, dateOfDeath, mother, father));
            }
        }
        catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    @Override
    public String toString() {
        StringBuilder sb= new StringBuilder("Person{" );
        sb.append("name='" + name + '\'' );
        if (dateOfBirth!=null){
            sb.append(", date of birth=" + dateOfBirth);
        }
        if (dateOfDeath!=null){
            sb.append(", date of death=" + dateOfDeath);
        }

        if (mother != null){
            sb.append(", mother=" + mother.name);
        }

        if (father != null){
           sb.append(", father=" + father.name);
        }
        sb.append( '}');
        return sb.toString();
    }
}

