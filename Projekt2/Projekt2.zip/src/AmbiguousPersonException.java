public class AmbiguousPersonException extends Exception{
    public AmbiguousPersonException(String name) {
        super(String.format("There is more than one person who has the same personal data: %s", name));
    }
}
